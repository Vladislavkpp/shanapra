<?php
/**
 * @var $md
 * @var $buf
 */
//require_once $_SERVER['DOCUMENT_ROOT'] .'/vendor/autoload.php';
require_once $_SERVER['DOCUMENT_ROOT'] ."/function.php";

if (isset($_GET['exit']) && $_GET['exit'] == 1) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

function Content(): string
{
    $dblink = DbConnect();
    $res = mysqli_query($dblink, "SELECT idx FROM grave");
    $count = $res ? mysqli_num_rows($res) : 0;
    mysqli_close($dblink);

    $out = '<div class="content">' .
        '<div class="login-formContainer">' .
        '<div class="form-title">Пошук інформації про померлих</div>' .
        '<form class="formindex" action="/searchx.php" method="get" lang="uk">' .
        '<input type="hidden" name="page" value="1">' .

        // Первый ряд ФИО
        '<div class="form-row form-vertical" lang="uk">' .

        '<div class="input-container">' .
        '<input type="text" name="surname" class="login-Input" placeholder=" " autocomplete="off">' .
        '<label>Прізвище</label>' .
        '</div>' .

        '<div class="input-container">' .
        '<input type="text" name="name" class="login-Input" placeholder=" " autocomplete="off">' .
        '<label>Ім\'я</label>' .
        '</div>' .

        '<div class="input-container">' .
        '<input type="text" name="patronymic" class="login-Input" placeholder=" " autocomplete="off">' .
        '<label>По-батькові</label>' .
        '</div>' .

        '<hr class="form-separator">' .
        '</div>' .

        // Второй ряд — даты
        '<div class="form-row form-row-dates" lang="uk">' .
        '<div class="input-container">' .
        '<input type="date" name="birthdate" placeholder=" " lang="uk">' .
        '<label>Дата народження</label>' .
        '</div>' .

        '<div class="input-container">' .
        '<input type="date" name="deathdate" placeholder=" " lang="uk">' .
        '<label>Дата смерті</label>' .
        '</div>' .
        '</div>' .

        '<div class="form-vertical">' .
        '<input type="submit" class="sub-btn" value="Знайти">' .
        '</div>' .
        '</form>' .
        '</div>' .
        '</div>';

    return $out;
}

function LeftBlock(): string
{
    $out = '<div id="about-us" class="left-block block">' .
        '<div class="form-title">Про нас</div>' .
        '<p>Інформація про нас...</p>' .
        '</div>';


    $out .= '<script>
document.addEventListener("DOMContentLoaded", function() {
    const anchors = document.querySelectorAll(\'a[href^="#"]\');

    anchors.forEach(anchor => {
        anchor.addEventListener("click", function(e) {
            e.preventDefault(); 
            const targetId = this.getAttribute("href").substring(1);
            const targetElem = document.getElementById(targetId);
            if (targetElem) {
                
                targetElem.scrollIntoView({ behavior: "smooth", block: "start" });

               
                targetElem.classList.remove("blink-highlight");

               
                setTimeout(() => {
                    targetElem.classList.add("blink-highlight");
                }, 500); 
            }
        });
    });
});
</script>

';

    return $out;
}


function StatsBlock(): string
{

    date_default_timezone_set('Europe/Kiev');

    $dblink = DbConnect();


    $res = mysqli_query($dblink, "SELECT COUNT(*) as cnt FROM grave");
    $row = $res ? mysqli_fetch_assoc($res) : ['cnt' => 0];
    $graveCount = $row['cnt'];


    $res2 = mysqli_query($dblink, "SELECT COUNT(*) as cnt FROM cemetery");
    $row2 = $res2 ? mysqli_fetch_assoc($res2) : ['cnt' => 0];
    $cemetryCount = $row2['cnt'];

    mysqli_close($dblink);

    $updated = date("d.m.Y");
    $updatedtime = date("H:i");

    $out = '<div class="stats-block block">' .
        '<div class="form-title">Статистика</div>' .
        '<div class="stats-index">Поховань у базі: <b>' . $graveCount . '</b></div>' .
        '<div class="stats-index">Кладовищ у базі: <b>' . $cemetryCount . '</b></div>' .
        '<hr class="form-separator-stats">' .
        '<div class="stats-updated">
            Оновлено: 
            <span class="date-part">' . date("d.m.Y") . '</span>
            <div class="search-divider-stat"></div>
            <span class="time-part">' . date("H:i") . '</span>
        </div></div>';

    return $out;
}




// === Вывод страницы ===
View_Clear();
View_Add(Page_Up());
View_Add(Menu_Up());

View_Add('<div class="out-index">');

View_Add(LeftBlock());
View_Add(Content());
View_Add(StatsBlock());

View_Add('</div>'); // .out

View_Add(Page_Down());
View_Out();
View_Clear();