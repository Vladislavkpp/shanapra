<?php
$auth_lifetime = 1800; // 30 минут

// Куки для хранения авторизации
$auth_cookie_name = 'user_auth';
$auth_cookie_value = '';

// Если пользователь выходит то:
if (isset($_GET['exit']) && $_GET['exit'] == 1) {
    setcookie($auth_cookie_name, '', time() - 3600, '/');
    session_unset();
    session_destroy();
    header("Location: /index.php");
    exit;
}

// Если пользователь авторизован через сессию — сохраняем в cookie
session_start();
if (isset($_SESSION['logged']) && $_SESSION['logged'] == 1) {
    $auth_cookie_value = $_SESSION['uzver'];
    setcookie($auth_cookie_name, $auth_cookie_value, time() + $auth_lifetime, '/');
}

if ((!isset($_SESSION['logged']) || $_SESSION['logged'] != 1) && isset($_COOKIE[$auth_cookie_name])) {
    $_SESSION['logged'] = 1;
    $_SESSION['uzver'] = $_COOKIE[$auth_cookie_name];
    $_SESSION['last_activity'] = time();
}



const xbr = "\n";
const no_grave_photo = '/graves/no_image_0.png';
$buf = '';
$dblink = null;
//$start = getmicrotime();
$md = isset($_GET['md']) ? $_GET['md'] : '';
$md = isset($_POST['md']) ? $_POST['md'] : $md;
$md = strtolower($md);
$ip = $_SERVER['REMOTE_ADDR'];
$login = '';
$password = '';
$loginix = 0;
$today = date('d-m-Y', time());
$todaysql = date('Y-m-d', time());
$todaydot = date('d.m.Y', time());
$yestertodaydot = date('d.m.Y', time() - 86400);


/*Для обработки выхода с каждой страницы*/
if (isset($_GET['exit']) && $_GET['exit'] == 1) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

function rus2lat($string)
{
    $rus = array('ё', 'ж', 'ц', 'ч', 'ш', 'щ', 'ю', 'я', 'Ё', 'Ж', 'Ц', 'Ч', 'Ш', 'Щ', 'Ю', 'Я', 'Ъ', 'Ь', 'ъ', 'ь');
    $lat = array('e', 'zh', 'c', 'ch', 'sh', 'sh', 'ju', 'ja', 'E', 'ZH', 'C', 'CH', 'SH', 'SH', 'JU', 'JA', '', '', '', '');
    $string = str_replace($rus, $lat, $string);
    return strtr($string, "АБВГДЕЗИЙКЛМНОПРСТУФХЫЭабвгдезийклмнопрстуфхыэ ", "ABVGDEZIJKLMNOPRSTUFHIEabvgdezijklmnoprstufhie_");
}

function getmicrotime()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

function warn($x = ''): string
{
    return '<div class="warn">' . $x . '</div>';
}

/**Створює підключення до бази даних
 * @return int|null|bool|mysqli
 */
function DbConnect(): int|null|bool|mysqli
{

    $db = 'bicycleb_shana';
    $dbuser = 'bicycleb_shanarw';
    $dbpassword = '@komnata44';
    $dblink = mysqli_connect("localhost", $dbuser, $dbpassword, $db);
    mysqli_query($dblink, "set character_set_client='utf8'");
    mysqli_query($dblink, "set character_set_results='utf8'");
    mysqli_query($dblink, "set collation_connection='utf8_general_ci'");


    return $dblink;
}

function View_Out()
{
    echo View_Get();
    View_Clear();
}

function View_Get(): string
{
    global $buf;
    return $buf;
}

/**Підготовлює буфер сторінки для нового виводу
 */
function View_Clear()
{
    global $buf;
    $buf = '';
}

function View_Add(null|string $a = '')
{
    global $buf;
    $buf .= $a;
}

function Menu_Up(): string {
    $out = '<div class="Menu_Up">';


    $out .= '<div class="menu-left">';
    $out .= '<div class="burger"><span></span><span></span><span></span></div>';
    $out .= '<div class="logo"><img src="/assets/images/logobrand2-full.png" alt="Логотип"></div>';
    $out .= '<div class="title">ІПС Шана</div>';
    $out .= '</div>';

    $out .= '<div class="menu-divider"></div>'; // вертикальная линия

    // Центральное меню
    $out .= '<div class="menu-center">';
    $out .= '<ul class="menu_ups"> 
        <li><a href="/">Головна</a></li>
        <li><a href="/workshana.php">Робота</a> 
            <ul class="submenu"> 
                <li><a href="/workshana.php">Прибирання кладовищ</a></li>
                <li><a href="/workshana.php">Виготовлення пам\'ятників</a></li>
                <li><a href="/workshana.php">Інші роботи</a></li>
            </ul>
        </li>
        <li><a href="/church.php">Церкви</a></li>
        <li><a href="/clients.php">Наші клієнти</a></li>
        <li><a href="/graveadd.php">Додати поховання</a></li>
        <li><a href="/docs/zadaniya.php">Завдання</a></li>
    </ul>';
    $out .= '</div>';

    // Правая часть — вход / аватар
    if (isset($_SESSION['logged']) && $_SESSION['logged'] == 1) {
        $dblink = DbConnect();
        $sql = 'SELECT avatar, cash, fname, lname FROM users WHERE idx = ' . intval($_SESSION['uzver']);
        $res = mysqli_query($dblink, $sql);
        if ($res && $user = mysqli_fetch_assoc($res)) {
            $avatar = ($user['avatar'] != '') ? $user['avatar'] : '/avatars/ava.png';
            $formattedCash = number_format($user['cash'], 0, '', '.');
            $firstName = $user['fname'];
            $lastName = $user['lname'];
            $lastNameShort = mb_substr($lastName, 0, 1) . '.';
            $fullname = htmlspecialchars($firstName . ' ' . $lastNameShort);
        }

        $out .= '<div class="login-btn dropdown">';
        $out .= '<input type="checkbox" id="dropdown-toggle" class="dropdown-checkbox" />';
        $out .= '<label for="dropdown-toggle" class="avatar-wrapper">';
        $out .= '<img class="menu-avatar" alt="profile" src="' . $avatar . '">';
        $out .= '<span class="user-fullname">' . $fullname . '</span>';
        $out .= '</label>';
        $out .= '<div class="dropdown-menu">';
        $out .= '<a href="/profile.php"><img src="/assets/images/profileicon.png" class="menu-icon"> Профіль</a>';
        //$out .= '<a href="#"><img src="/assets/images/notification.png" class="menu-icon"> Сповіщення</a>';
        $out .= '<a href="/profile.php?md=4"><img src="/assets/images/balanceprof.png" class="menu-icon"> Баланс: ₴' . $formattedCash . ' </a>';
        $out .= '<a href="profile.php?md=2"><img src="/assets/images/setting.png" class="menu-icon"> Налаштування</a>';
        //$out .= '<a href="#"><img src="/assets/images/support.png" class="menu-icon"> Підтримка</a>';
        $out .= '<hr>';
        $out .= '<a href="?exit=1" class="logout"><img src="/assets/images/logbtn.png" class="menu-icon"> Вийти</a>';
        $out .= '</div>';
        $out .= '<label for="dropdown-toggle" class="page-overlay"></label>';
        $out .= '</div>';
    } else {
        $out .= '<div class="login-btn"><a class="login-link" href="/auth.php">Увійти</a></div>';
    }

    $out .= '</div>';


    $out .= '
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const burger = document.querySelector(".burger");
        const menu = document.querySelector(".menu-center");

        if (burger && menu) {
            burger.addEventListener("click", function () {
                burger.classList.toggle("active");
                menu.classList.toggle("active");
            });
        }
    });
    </script>
    ';

    return $out;
}



function Menu_Left(): string
{
    $out = '<div class="Menu_Left">';
    $out .= '<a href="index.php" class="menu-link">Головна</a>';
    $out .= '<a href="graveadd.php" class="menu-link">Поховання</a>';
    $out .= '</div>';
    return $out;
}


function Page_Up($ttl = ''): string
{
    $out = '<!DOCTYPE html>' . xbr .
        '<html lang="uk">' . xbr .
        '<head>' . xbr .
        '<title>ІПС Shana | ' . $ttl . '</title>' . xbr .
        '<meta charset="utf-8">' . xbr .
        '<meta http-equiv="Content-Type" content="text/html">' . xbr .
        '<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=1, shrink-to-fit=yes">' . xbr .
        '<meta name="robots" content="all">' . xbr .
        '<link rel="stylesheet" href="/assets/css/common.css">' . xbr .
        '<script>
 
  history.pushState(null, "", location.href);
  window.addEventListener("popstate", function() {
      window.location.href = "/";
      //не полностью работает так как надо.
  });
</script>
' . xbr .
        '</head>' . xbr .
        '<body class="bg-dark">' . xbr .
        '<div id="wrapper" class="wrapper">' . xbr;
    return $out;
}

function Page_Down(): string
{
    $out = '<div class="Page_Down">';
    $out .= '<ul class="menu_down">
<li><a href="#about-us">About Us</a></li>
<li><a href="/">FAQ</a></li>
<li><a href="/">Contacts</a></li>
<li><a href="/">NpInfo</a></li>
<li><a href="/">Copyright</a></li>
<li><a href="/">Links</a></li>
</ul>';
    $out .= '<hr class="page-down-hr">';
    $out .= '<div class="copyright">© 2025 shanapra</div>';
    $out .= '</div>' . xbr;
    $out .= '</body></html>';
    return $out;
}


function Contentx(): string
{
    $out = '<div class = "content">';

    $out .= '</div>';
    return $out;
}

function View_Add_Warn($mes = ''): string
{
    global $md;
    $out = '<div class="warn">md=' . $md . '** ' . $mes . '</div>';

    return $out;
}

function DbsCount(): int
{
    global $dblink;
    $dblink = DbConnect();
    $sql = 'SELECT count(idx) as t1 FROM grave';
    $res = mysqli_query($dblink, $sql);
    if (!$res) {
        $out = 0;
    } else {
        $ou = mysqli_fetch_assoc($res);
        $out = $ou['t1'];
    }
    return $out;
}

/*function RegionSelect($n="",$c=""):string
{
    return
    '<select name="'.$n.'" class="'.$c.'" required> ' .
    ' <option value="" disabled selected>Виберіть місто</option> ' .
    ' <option>Київ</option> ' .
    '<option>Вінниця</option> ' .
    '<option>Дніпро</option> ' .
    '<option>Донецьк</option> ' .
    '<option>Житомир</option>' .
    '<option>Запоріжжя</option>' .
    '<option>Івано‑Франківськ</option>' .
    '<option>Кропивницький</option>' .
    '<option>Луганськ</option>' .
    '<option>Луцьк</option>' .
    '<option>Львів</option>' .
    '<option>Миколаїв</option>' .
    '<option>Одеса</option>' .
    '<option>Полтава</option>' .
    '<option>Рівне</option>' .
    '<option>Сімферополь</option>' .
    '<option>Суми</option>' .
    '<option>Тернопіль</option>' .
    '<option>Ужгород</option>' .
    '<option>Харків</option>' .
    '<option>Херсон</option>' .
    '<option>Хмельницький</option>' .
    '<option>Черкаси</option>' .
    '<option>Чернівці</option>' .
    '<option>Чернігів</option>' .

    '</select>' ;
}*/

if (isset($_GET['ajax_districts']) && isset($_GET['region_id'])) {
    $region_id = intval($_GET['region_id']);
    $dblink = DbConnect();

    // Берём id и название
    $res = mysqli_query($dblink, "SELECT idx, title FROM district WHERE region = $region_id ORDER BY title");
    mysqli_close($dblink);

    if ($res && mysqli_num_rows($res) > 0) {
        echo '<option value="">Виберіть район</option>';
        while ($row = mysqli_fetch_assoc($res)) {
            // value = id, текст = название
            echo '<option value="' . (int)$row['idx'] . '">' . htmlspecialchars($row['title']) . '</option>';
        }
    } else {
        echo '<option value="">Райони не знайдено</option>';
    }
    exit;
}



function RegionSelect($n = "region", $c = "")
{
    $dblink = DbConnect();
    $res = mysqli_query($dblink, "SELECT idx, title FROM region ORDER BY title");
    mysqli_close($dblink);

    $out = '<select name="' . $n . '" id="region" class="' . $c . '" onchange="loadDistricts(this.value)" required>';
    $out .= '<option value="" disabled selected>Виберіть область</option>';

    while ($row = mysqli_fetch_assoc($res)) {
        $out .= '<option value="' . $row['idx'] . '">' . $row['title'] . '</option>';
    }

    $out .= '</select>';
    return $out;
}


function RegionForKladb($n = "region", $c = "")
{
    $dblink = DbConnect();
    $res = mysqli_query($dblink, "SELECT idx, title FROM region ORDER BY title");
    mysqli_close($dblink);

    $out = '<select name="' . $n . '" id="region" class="' . $c . '" onchange="loadDistricts(this.value)">';
    $out .= '<option value="" selected hidden>Виберіть область</option>';

    while ($row = mysqli_fetch_assoc($res)) {
        $out .= '<option value="' . $row['idx'] . '">' . $row['title'] . '</option>';
    }

    $out .= '</select>';
    return $out;
}

function RegionForCem($n = "region", $c = "")
{
    $dblink = DbConnect();
    $res = mysqli_query($dblink, "SELECT idx, title FROM region ORDER BY title");
    mysqli_close($dblink);

    $out = '<select name="' . $n . '" id="region" class="' . $c . '" required onchange="loadDistricts(this.value)">';

    $out .= '<option value="" selected hidden>Виберіть область</option>';

    while ($row = mysqli_fetch_assoc($res)) {
        $out .= '<option value="' . $row['idx'] . '">' . $row['title'] . '</option>';
    }

    $out .= '</select>';
    return $out;
}


// Районы по области
function getDistricts($region_id)
{
    $dblink = DbConnect();
    $region_id = (int)$region_id;

    $res = mysqli_query($dblink, "SELECT idx, title FROM district WHERE region = $region_id ORDER BY title");

    $out = '<option value="">Оберіть район</option>';
    while ($row = mysqli_fetch_assoc($res)) {
        $out .= '<option value="' . (int)$row['idx'] . '">' . htmlspecialchars($row['title']) . '</option>';
    }

    mysqli_close($dblink);
    return $out;
}

// Населенные пункты по району и области
function getSettlements($region_id, $district_id)
{
    $dblink = DbConnect();
    $region_id = (int)$region_id;
    $district_id = (int)$district_id;

    $sql = "SELECT idx, title 
            FROM misto 
            WHERE idxregion = $region_id 
              AND idxdistrict = $district_id 
            ORDER BY title";

    $res = mysqli_query($dblink, $sql);

    $out = '<option value="">Оберіть населений пункт</option>';
    while ($row = mysqli_fetch_assoc($res)) {

        $out .= '<option value="' . (int)$row['idx'] . '">' . htmlspecialchars($row['title']) . '</option>';
    }

    mysqli_close($dblink);
    return $out;
}



// Добавление нового населённого пункта
function addSettlement($region_id, $district_id, $name)
{
    $dblink = DbConnect();
    $region_id = (int)$region_id;
    $district_id = (int)$district_id;
    $name = mysqli_real_escape_string($dblink, trim($name));

    if ($name === "") {
        return "Помилка: пуста назва";
    }

    $sql = "INSERT INTO misto (title, idxdistrict, idxregion) VALUES ('$name', $district_id, $region_id)";
    if (mysqli_query($dblink, $sql)) {
        $out = "OK: додано";
    } else {
        $out = "Помилка: " . mysqli_error($dblink);
    }

    mysqli_close($dblink);
    return $out;
}



function Cardsx(
    int $idx = 0,
    string $f = '',
    string $i = '',
    string $o = '',
    string $d1 = '',
    string $d2 = '',
    string $img = ''
): string {

    if (!is_file($_SERVER['DOCUMENT_ROOT'].$img)) {
        $img = '/graves/noimage.jpg';
    }

    $out  = '<div class="cardx">';

    // фото
    $out .= '  <div class="cardx-img">';
    $out .= '      <img src="'.$img.'" class="cardx-image" alt="'.$f.' '.$i.' '.$o.'" title="'.$f.' '.$i.' '.$o.'">';
    $out .= '  </div>';

    // блок с данными
    $out .= '  <div class="cardx-data">';
    $out .= '      <div class="text2center font-bold font-white height50">';
    $out .=            $f.' '.$i.' '.$o.'<br>';
    $out .= '      </div>';
    $out .= '      <div class="text2center font-white">';
    $out .=            DateFormat($d1).' - '.DateFormat($d2).'<br>';
    $out .= '      </div>';
    $out .= '      <div class="text2right">';
    $out .= '          <a href="/cardout.php?idx='.$idx.'">Детали</a>';
    $out .= '      </div>';
    $out .= '  </div>';

    $out .= '</div>';

    return $out;
}

function CardsK(
    int $idx = 0,
    string $title = '',
    string $town = '',
    string $district = '',
    string $adress = '',
    string $img = ''
): string {

    $dblink = DbConnect();


    if (!empty($district) && ctype_digit((string)$district)) {
        $res = mysqli_query($dblink, "SELECT title FROM district WHERE idx=".(int)$district." LIMIT 1");
        if ($res && $row = mysqli_fetch_assoc($res)) {
            $district = $row['title'];
        }
    }

    if (!is_file($_SERVER['DOCUMENT_ROOT'].$img) || empty($img)) {
        $img = '/graves/noimage.jpg';
    }

    $out  = '<div class="cardk">';

    // фото
    $out .= '  <div class="cardk-img">';
    $out .= '      <img src="'.$img.'" class="cardk-image" alt="'.htmlspecialchars($title).'" title="'.htmlspecialchars($title).'">';
    $out .= '  </div>';

    // блок с данными
    $out .= '  <div class="cardk-data">';

    // Заголовок
    $out .= '      <div class="cardk-title font-bold">'.$title.'</div>';


    if ($town !== '') {
        $out .= '      <div class="cardk-town"><b>Місто:</b> '.$town.'</div>';
    }

    // Район
    if ($district !== '') {
        $out .= '      <div class="cardk-district"><b>Район:</b> '.$district.'</div>';
    }

    // Адрес
    if ($adress !== '') {
        $out .= '      <div class="cardk-adress"><b>Адреса:</b> '.$adress.'</div>';
    }


    $out .= '  </div>'; // .cardk-data
    $out .= '  <div class="cardk-footer">';
    $out .= '      <a href="/cemetery.php?idx='.$idx.'" class="cardk-link">Деталі</a>';
    $out .= '  </div>';
    $out .= '</div>';   // .cardk

    return $out;
}



class Paginatex
{
    public static function Showx(int $current, int $total, int $perpage): string
    {
        $countPages = ceil($total / $perpage);
        if ($countPages <= 1) return '';


        $prevIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>';
        $nextIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>';
        $firstIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 19l-7-7 7-7M18 5v14"/></svg>';
        $lastIcon  = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M13 5l7 7-7 7M6 19V5"/></svg>';

        $html = '<ul>';


        $query = $_GET;
        unset($query['page']);
        $zapr = http_build_query($query);

        $zapr = $zapr ? "&$zapr" : "";

        // В начало
        if ($current > 1) {
            $html .= '<li><a href="?page=1' . $zapr . '">' . $firstIcon . '</a></li>';
        } else {
            $html .= '<li><span class="disabled">' . $firstIcon . '</span></li>';
        }

        // Назад
        if ($current > 1) {
            $html .= '<li><a href="?page=' . ($current - 1) . $zapr . '">' . $prevIcon . '</a></li>';
        } else {
            $html .= '<li><span class="disabled">' . $prevIcon . '</span></li>';
        }

        // Номера страниц
        $start = max(1, $current);
        $end = min($start + 2, $countPages);
        if ($end - $start < 2 && $start > 1) {
            $start = max(1, $end - 2);
        }

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $current) {
                $html .= '<li><span class="current">' . $i . '</span></li>';
            } else {
                $html .= '<li><a href="?page=' . $i . $zapr . '">' . $i . '</a></li>';
            }
        }

        // Вперёд
        if ($current < $countPages) {
            $html .= '<li><a href="?page=' . ($current + 1) . $zapr . '">' . $nextIcon . '</a></li>';
        } else {
            $html .= '<li><span class="disabled">' . $nextIcon . '</span></li>';
        }

        // В конец
        if ($current < $countPages) {
            $html .= '<li><a href="?page=' . $countPages . $zapr . '">' . $lastIcon . '</a></li>';
        } else {
            $html .= '<li><span class="disabled">' . $lastIcon . '</span></li>';
        }

        $html .= '</ul>';
        return $html;
    }
}
