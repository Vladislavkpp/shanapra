<?php
/**
 * @var $md
 * @var $buf
 */
//require_once $_SERVER['DOCUMENT_ROOT'] .'/vendor/autoload.php';
require_once $_SERVER['DOCUMENT_ROOT'] ."/function.php";

function ContentFeed(): string {
    $out = '<div class="feed">
    <div class="feed-create">
        <div class="feed-avatar">
            <img src="" alt="Аватар">
        </div>
        <div class="feed-input">
            <input type="text" placeholder="Что у вас нового?" readonly>
        </div>
    </div>
</div>';

    return $out;
}

function PageLayout(): string {
    $out  = '<div class="page-layout">';

    // Левая
    $out .= '<aside class="sidebar-left">';
    $out .= '  <div class="action-bar">';
    $out .= '      <ul>';
    $out .= '          <li><a href="#">Профиль</a></li>';
    $out .= '          <li><a href="#">Друзья</a></li>';
    $out .= '          <li><a href="#">Сохраненное</a></li>';
    $out .= '          <li><a href="#">...</a></li>';
    $out .= '      </ul>';
    $out .= '  </div>';
    $out .= '</aside>';

    // Центр (лента)
    $out .= '<main class="content">';
    $out .= ContentFeed();
    $out .= '</main>';

    // Правая
    $out .= '<aside class="sidebar-right">';
    $out .= '  <div class="widgets">';
    $out .= '      <div class="widget">Уведомления</div>';
    $out .= '      <div class="widget">Чаты</div>';
    $out .= '  </div>';
    $out .= '</aside>';

    $out .= '</div>';

    return $out;
}



// === Вывод страницы ===
View_Clear();
View_Add(Page_Up());
View_Add('<link rel="stylesheet" href="/assets/css/socpage.css">');
View_Add(Menu_Up());


View_Add('<div class="out">');

View_Add(PageLayout());
//View_Add(ContentFeed());

View_Add('</div>');

View_Add(Page_Down());
View_Out();
View_Clear();