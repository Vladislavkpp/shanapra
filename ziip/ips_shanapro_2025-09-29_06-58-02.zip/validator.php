<?php

/**
 * @var $md
 * @var $buf
 */
//require_once $_SERVER['DOCUMENT_ROOT'] .'/vendor/autoload.php';
require_once "function.php";


function valide1($u = null){
    //Проверка на длину пароля
    //Проверка на язык
    //Проверка на симовлы
    //проверка регистра
    //недопустимые символы  и слова
    return '11111';
}